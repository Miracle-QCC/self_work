import torch
import gym
from DQN import DDQN_Agent
import matplotlib.pyplot as plt

device = 'cuda' if torch.cuda.is_available() else 'cpu'

def reward_func(env, x, x_dot, theta, theta_dot):
    r1 = (env.x_threshold - abs(x)) / env.x_threshold - 0.5
    r2 = (env.theta_threshold_radians - abs(theta)) / env.theta_threshold_radians - 0.5
    reward = r1 + r2
    return reward

if __name__ == '__main__':

    env = gym.make("CartPole-v0")
    state_dim = env.observation_space.shape[0]
    act_dim = env.action_space.n
    params = {
        'gamma': 0.8,
        'epsi_high': 0.9,
        'epsi_low': 0.05,
        'decay': 200,
        'lr': 0.001,
        'capacity': 10000,
        'batch_size': 64,
        'state_space_dim': env.observation_space.shape[0],
        'action_space_dim': env.action_space.n,
    }
    # agent = DDQN_Agent(state_dim,act_dim)

    agent = DDQN_Agent(**params)
    score = []
    mean = []
    for episode in range(100):
        s0 = env.reset()
        total_reward = 1
        for i in range(200):
            # env.render()
            a0 = agent.act(s0)
            s1, r1, done, _ = env.step(a0)

            if done:
                r1 = -1

            agent.put(s0, a0, r1, s1, done)

            if done:
                break

            total_reward += r1
            s0 = s1
            agent.update()

        score.append(total_reward)
        mean.append(sum(score[-100:]) / 100)
        print(f'{episode} reward :',total_reward)
    # plot(score, mean)
    plt.title('Training...')
    plt.xlabel('Episode')
    plt.ylabel('Reward')
    plt.plot(score)
    plt.plot(mean)
    # plt.text(len(score) - 1, score[-1], str(score[-1]))
    # plt.text(len(mean) - 1, mean[-1], str(mean[-1]))
    plt.savefig("rewards_episode.png")



