import gym
import torch
import numpy as np
from tqdm import tqdm
import matplotlib.pyplot as plt
from ppo_agent import PPOTrainer
device = 'cuda' if torch.cuda.is_available() else 'cpu'

env = gym.make("BipedalWalker-v3")
env.seed(42)
env.action_space.seed(42)
torch.manual_seed(42)
torch.random.manual_seed(42)
np.random.seed(42)

if __name__ == '__main__':
    trainer = PPOTrainer(env)

    Episodes = 500
    for e in tqdm(range(Episodes)):
        trainer.train(trainer.sample(), 0.2)

    trainer.save_checkpoint()
    plt.xlabel('episode')
    plt.ylabel('rewards')
    plt.plot(trainer.all_mean_rewards)
    plt.savefig("mean_reward_{}.png".format(trainer.episode))
    plt.clf()
