#include "nxsdk.h"
int do_encoder(runState *s);
void run_encoder(runState *s);