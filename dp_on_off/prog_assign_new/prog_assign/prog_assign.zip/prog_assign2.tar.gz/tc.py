import numpy as np
from algo import ValueFunctionWithApproximation

class ValueFunctionWithTile(ValueFunctionWithApproximation):
    def __init__(self,
                 state_low:np.array,
                 state_high:np.array,
                 num_tilings:int,
                 tile_width:np.array):
        """
        state_low: possible minimum value for each dimension in state
        state_high: possible maximum value for each dimension in state
        num_tilings: # tilings
        tile_width: tile width for each dimension
        """
        # TODO: implement this method

        self.state_low = state_low
        self.state_high = state_high
        self.num_tilings = num_tilings
        self.tile_width = tile_width

        # Calculate the number of tiles in each dimension
        num_tiles_per_dim = np.ceil((state_high - state_low) / tile_width).astype(int) + 1

        # Initialize tile coding parameters
        self.num_dimensions = len(state_low)
        self.num_tiles = np.prod(num_tiles_per_dim)  # Total number of tiles
        self.tile_offsets = [i * tile_width / num_tilings for i in range(num_tilings)]

        # Initialize weights for each tile
        self.weights = np.zeros(self.num_tiles * num_tilings)


    def __call__(self,s):
        # TODO: implement this method
        tiles = self.get_tiles(s)
        return np.sum(self.weights[tiles])

    def update(self,alpha,G,s_tau):
        # TODO: implement this method
        tiles = self.get_tiles(s_tau)
        error = G - self(s_tau)
        self.weights[tiles] += alpha * error

    def get_tiles(self, state):
        """
        Get the tiles for a given state.

        state: input state
        """
        tiles = []
        for tiling_index in range(self.num_tilings):
            tile = []
            for dim in range(self.num_dimensions):
                tile_value = int(
                    (state[dim] - self.state_low[dim] + tiling_index * self.tile_offsets[tiling_index][dim]) /
                    self.tile_width[dim])
                # Ensure tile values are within valid range
                tile_value = np.clip(tile_value, 0, np.ceil(
                    (self.state_high[dim] - self.state_low[dim]) / self.tile_width[dim]).astype(int))
                tile.append(tile_value)
            tiles.append(tile)


        return np.ravel_multi_index(np.array(tiles).T, dims=[np.ceil((high - low) / tile_width).astype(int) + 1 for
                                                             low, high, tile_width in
                                                             zip(self.state_low, self.state_high, self.tile_width)])
        # except ValueError as e:
        #     print("Error in get_tiles:", e)
        #     print("State:", state)
        #     print("Tiles:", tiles)
        #     raise





