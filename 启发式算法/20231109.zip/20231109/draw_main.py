import matplotlib.pyplot as plt
import pandas as pd

if __name__=="__main__":
    df_origin = pd.read_csv('./1_rounds_original_result.csv')
    df_opt = pd.read_csv('./1_rounds_result.csv')
    plt.figure()
    plt.title(f'Compare')
    plt.plot(df_origin['best'].tolist(),label='ACO')
    plt.plot(df_opt['best'].tolist(),label='OPT-ACO')
    plt.grid(True)
    plt.legend()
    plt.show()