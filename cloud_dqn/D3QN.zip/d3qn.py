import torch as T
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import numpy as np
from buffer import ReplayBuffer
from buffer1 import Memory

device = T.device("cuda:0" if T.cuda.is_available() else "cpu")


class DuelingDeepQNetwork(nn.Module):
    def __init__(self, alpha, state_dim, action_dim, fc1_dim):
        super(DuelingDeepQNetwork, self).__init__()

        self.fc1 = nn.Linear(state_dim, fc1_dim)
        self.fc2 = nn.Linear(fc1_dim, fc1_dim)
        self.fc3 = nn.Linear(fc1_dim, fc1_dim)
        self.fc4 = nn.Linear(fc1_dim, fc1_dim)
        self.fc5 = nn.Linear(fc1_dim, fc1_dim)

        self.V = nn.Linear(fc1_dim, 1)
        self.A = nn.Linear(fc1_dim, action_dim)

        self.optimizer = optim.Adam(self.parameters(), lr=alpha)
        self.to(device)

    def forward(self, state):
        x = T.relu(self.fc1(state))
        x = T.relu(self.fc2(x))
        x = T.relu(self.fc3(x))
        x = T.relu(self.fc4(x))
        x = T.relu(self.fc5(x))

        V = self.V(x)
        A = self.A(x)
        Q = V + A - T.mean(A, dim=-1, keepdim=True)

        return Q

    def save_checkpoint(self, checkpoint_file):
        T.save(self.state_dict(), checkpoint_file)

    def load_checkpoint(self, checkpoint_file):
        self.load_state_dict(T.load(checkpoint_file))


def my_mse_loss(x, y, z):  # 自定义损失函数 ***
    return T.mean(z * (T.pow((x - y), 2)))


def my_sum_loss(x, y):  # 更新优先级函数 ***
    return T.abs(x - y)


class D3QN:
    def __init__(self, alpha, state_dim, action_dim, fc1_dim, ckpt_dir,
                 gamma=0.99, tau=0.005, epsilon=1.0, eps_end=0.01, eps_dec=5e-7,
                 max_size=1000000, batch_size=256,is_prioritized=False,step_update=False,step_period=200):
        self.gamma = gamma
        self.tau = tau
        self.epsilon = epsilon
        self.eps_min = eps_end
        self.eps_dec = eps_dec
        self.batch_size = batch_size
        self.step_update = step_update
        self.step_period = step_period
        self.step_n = 0
        # 是否采用优先级经验回放 ***
        self.prioritized = is_prioritized
        self.state_dim = state_dim
        self.action_dim = action_dim
        
        self.checkpoint_dir = ckpt_dir
        self.action_space = [i for i in range(action_dim)]

        self.q_eval = DuelingDeepQNetwork(alpha=alpha, state_dim=state_dim, action_dim=action_dim,
                                          fc1_dim=fc1_dim)
        self.q_target = DuelingDeepQNetwork(alpha=alpha, state_dim=state_dim, action_dim=action_dim,
                                            fc1_dim=fc1_dim)

        # 经验回放 ***
        if self.prioritized:
            self.memory = Memory(max_size=max_size, batch_size=batch_size)
        else:
            self.memory = ReplayBuffer(state_dim=state_dim, action_dim=action_dim,
                                       max_size=max_size, batch_size=batch_size)

        self.update_network_parameters(tau=1.0)

    def update_network_parameters(self, tau=None):
        if tau is None:
            tau = self.tau

        for q_target_params, q_eval_params in zip(self.q_target.parameters(), self.q_eval.parameters()):
            q_target_params.data.copy_(tau * q_eval_params + (1 - tau) * q_target_params)

    def remember(self, state, action, reward, state_, done):
        # 保存经验 ***
        self.memory.store_transition(state, action, reward, state_, done)

    # ***
    def epsilon_increment(self, n_iter, N_iter):
        self.epsilon = self.epsilon - (self.epsilon - self.eps_min) * min(1, n_iter / N_iter)

    def choose_action(self, observation, isTrain=True):
        state = T.tensor(observation, dtype=T.float).to(device)
        actions = self.q_eval.forward(state)
        action = T.argmax(actions).item()

        if (np.random.random() < self.epsilon) and isTrain:
            action = np.random.choice(self.action_space)

        return action

    def learn(self):
        if not self.memory.ready():
            return

        if self.prioritized:
            tree_idx, minibatch, ISWeights = self.memory.sample_buffer(self.batch_size)
            states = minibatch[:, 0:self.state_dim]
            actions = minibatch[:, self.state_dim:self.state_dim + 1]
            rewards = minibatch[:, self.state_dim + 1:self.state_dim + 2]
            next_states = minibatch[:, self.state_dim + 2:-1]
            terminals = minibatch[:, -1]
            ISWeights_tensor = T.tensor(ISWeights, dtype=T.float).to(device)
        else:
            states, actions, rewards, next_states, terminals = self.memory.sample_buffer()

        batch_idx = np.arange(self.batch_size)

        states_tensor = T.tensor(states, dtype=T.float).to(device)
        rewards_tensor = T.tensor(rewards, dtype=T.float).to(device)
        next_states_tensor = T.tensor(next_states, dtype=T.float).to(device)
        terminals_tensor = T.tensor(terminals, dtype=T.bool).to(device)

        with T.no_grad():
            q_ = self.q_eval.forward(next_states_tensor)
            next_actions = T.argmax(q_, dim=-1)
            q_ = self.q_target.forward(next_states_tensor)
            # terminals = done时是的下一状态是最终态，需要排除
            q_[terminals_tensor] = 0.0
            target = rewards_tensor.flatten() + self.gamma * q_[batch_idx, next_actions]
        
        q = self.q_eval.forward(states_tensor)[batch_idx, actions[:, 0]]

        if self.prioritized:
            abs_errors = my_sum_loss(q, target.detach())  # for updating Sumtree
            loss = my_mse_loss(q, target.detach(), ISWeights_tensor.flatten())
            # print('!!!')
            # print(tree_idx)
            # print(q)
            # print(target.detach())
            # print(abs_errors)
            # print(abs_errors.detach().numpy())
            # 在GPU上有修改
            self.memory.batch_update(tree_idx, abs_errors.detach().cpu().numpy())  # update priority
        else:
            loss = F.mse_loss(q, target.detach())
        
        self.q_eval.optimizer.zero_grad()
        loss.backward()
        self.q_eval.optimizer.step()

        self.step_n += 1
        if self.step_update:
            if self.step_n == self.step_period:
                self.step_n = 0
                self.update_network_parameters(1)
        else:
            self.update_network_parameters()

    def save_models(self, episode):
        self.q_eval.save_checkpoint(self.checkpoint_dir + 'Q_eval/D3QN_q_eval_{}.pth'.format(episode))
        print('Saving Q_eval network successfully!')
        self.q_target.save_checkpoint(self.checkpoint_dir + 'Q_target/D3QN_Q_target_{}.pth'.format(episode))
        print('Saving Q_target network successfully!')

    def load_models(self, episode):
        self.q_eval.load_checkpoint(self.checkpoint_dir + 'Q_eval/D3QN_q_eval_{}.pth'.format(episode))
        print('Loading Q_eval network successfully!')
        self.q_target.load_checkpoint(self.checkpoint_dir + 'Q_target/D3QN_Q_target_{}.pth'.format(episode))
        print('Loading Q_target network successfully!')
